# WEGYM Multi-Page Starter Website

Open index.html in your browser.

Pages included:
- index.html
- workout-videos.html
- workout-plans.html
- diets.html
- equipment.html
- supplements.html

CSS is in css/style.css.
JavaScript is in js/script.js.

The chest video is WVID-001: Cable Flies.
