const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

if (menuBtn && navLinks) {
  menuBtn.addEventListener("click", function () {
    navLinks.classList.toggle("show");
  });
}

const filterButtons = document.querySelectorAll(".filter-btn");
const workoutCards = document.querySelectorAll(".workout-video-card");

filterButtons.forEach(function (button) {
  button.addEventListener("click", function () {
    const selectedFilter = button.getAttribute("data-filter");

    filterButtons.forEach(function (btn) {
      btn.classList.remove("active");
    });

    button.classList.add("active");

    workoutCards.forEach(function (card) {
      const bodyPart = card.getAttribute("data-bodypart");

      if (selectedFilter === "all" || selectedFilter === bodyPart) {
        card.classList.remove("hidden");
      } else {
        card.classList.add("hidden");
      }
    });
  });
});
